$(document).ready(() => {

    $(document).on("click", "#Deposit1", function() {
        depositForm()
    })

    $(document).on("click", "#Deposit2", function() {
        depositForm()
    })

    $(document).on("click", "#withdrawal1", function() {
        withdrawalForm()
    })

    $(document).on("click", "#withdrawal2", function() {
        withdrawalForm()
    })

    function withdrawalForm() {
        template = `
        <div class="col-md-2 text-muted" id="side">
        <ul>
            <li class="mb-4">
                <i class="fa fa-user mr-1"></i>
                loading...
            </li>
            <li class="bg-info p-2">
                <i class="fa fa-dashboard text-white"></i>
                <a href="./dashboard.php" class="text-white">Dashboard</a></li>
            <li>
                <a href="javascript:void(0);" id="Deposit2" class="text-muted">
                    <i class="fa fa-credit-card"></i>
                    <span>Deposits</span></a>
            </li>
            <li>
                <a href="javascript:void(0);" id="withdrawal2" class="text-muted">
                    <i class="fa fa-wallet"></i>
                    <span>Withdrawals</span>
                </a>
            </li>
            <li id="logout2">
                Logout<i class="fa fa-sign-out ml-1"></i>
            </li>
        </ul>
    </div>
                <div class="col-md-3 box" id="box1">
                    <span class="badge badge-danger">
                       Earnings
                </span>
                    <div class="mt-3 d-flex">
                        <i class="fa fa-money fa-3x mr-3"></i>
                        <h4><b>Usd</b></h4>
                        <h4 class="ml-3"><b>00.00</b></h4>
                    </div>
                </div>
                <div class="col-md-3 box pt-5" id="box4">
                <center>
                <h5 class="text-muted">Withdraw Fund</h5>
                   <form class="form-group pt-5">
                        <input type="number" name="amount" placeholder="Enter Amount" class="form-control mb-2">
                        <input type="submit" class="btn btn-info" value="process withdrawal">
                   </form>
                   </center>
                </div>
                <div class="col-md-3 box" id="box3">
                    <h5 class="text-muted p-3">Withdrawal History</h5>
                    <div class="d-flex">
                        <h6 class="text-muted ml-1 mr-5">Tnx</h6>
                        <h6 class="text-muted ml-5">Amount</h6>
                        <h6 class="text-muted ml-4">Date</h6>
                    </div>
                    <hr>
                </div>
        `
        $("#app").fadeIn();
        $("#app").empty()
        $("#app").append(template)
    }

    function depositForm() {

        template = `
        <div class="col-md-2 text-muted" id="side">
        <ul>
            <li class="mb-4">
                <i class="fa fa-user mr-1"></i>
                loading...
            </li>
            <li class="bg-info p-2">
                <i class="fa fa-dashboard text-white"></i>
                <a href="./dashboard.php" class="text-white">Dashboard</a></li>
            <li>
                <a href="javascript:void(0);" id="Deposit2" class="text-muted">
                    <i class="fa fa-credit-card"></i>
                    <span>Deposits</span></a>
            </li>
            <li>
                <a href="javascript:void(0);" id="withdrawal2" class="text-muted">
                    <i class="fa fa-wallet"></i>
                    <span>Withdrawals</span>
                </a>
            </li>
            <li id="logout2">
                Logout<i class="fa fa-sign-out ml-1"></i>
            </li>
        </ul>
    </div>
                <div class="col-md-3>
                </div>
                <div class="col-md-6" style="margin-top:300px;margin-left:200px;">
                <center>
                <h4>in progress.....</h4>
                </center>
                </div>
        `
        $("#app").fadeIn();
        $("#app").empty()
        $("#app").append(template)

    }

    $("#login").submit((e) => {
        e.preventDefault();
        email = $("#email").val();
        password = $("#password").val();

        $.ajax({
            url: "../controller/controller.php",
            type: "post",
            data: {
                "login": "login",
                "email": email,
                "password": password
            },
            dataType: "JSON",
            success: function(data) {
                if (data.status == "success") {
                    location.href = "./dashboard.php"
                } else {
                    error = ` <center>
                            <h4 class="p-auto bg-warning rounded text-white">${data.message}</h4>
                        </center>`

                    $(".error").append(error);
                    $(".error").fadeIn();
                    setTimeout(function() {
                        $(".error").empty()
                    }, 3000)
                }
            }
        })
    })

    $("#signup").submit((e) => {
        e.preventDefault();
        fname = $("#fname").val();
        lname = $("#lname").val();
        email = $("#email").val();
        password = $("#password").val();
        cpassword = $("#cpassword").val();
        if (password == cpassword) {
            if (password.length > 8) {
                $.ajax({
                    url: "../controller/controller.php",
                    type: "post",
                    data: {
                        "signup": "signup",
                        "fname": fname,
                        "lname": lname,
                        "email": email,
                        "password": password,
                        "cpassword": cpassword
                    },
                    dataType: "JSON",
                    success: function(data) {
                        if (data.status == "success") {
                            window.location.href = "./dashboard.php"
                        } else {
                            console.log(data);
                        }
                    }
                })
            } else {
                error = ` <center>
                    dataType: "JSON",
                        <h6 class="p-auto bg-warning rounded text-white">Password length must exceed 8characters</h6>
                    </center>`

                $(".error").append(error);
                $(".error").fadeIn();
                setTimeout(function() {
                    $(".error").empty()
                }, 3000)
            }
        } else {
            error = ` <center>
                        <h6 class="p-auto bg-danger rounded text-white">passwords doesnt match</h6>
                    </center>`

            $(".error").append(error);
            $(".error").fadeIn();
            setTimeout(function() {
                $(".error").empty()
            }, 3000)
        }
    })



    $("#logout1").click(() => {
        logout()
    })

    $("#logout2").click(() => {
        logout()
    })


    function logout() {
        $.ajax({
            url: "../controller/controller.php",
            type: "post",
            data: {
                "logout": "logout"
            },
            success: function(data) {
                if (data.status == "failed") {
                    return false
                } else {
                    location.href = "./login.php"
                }
            }
        })
    }
})